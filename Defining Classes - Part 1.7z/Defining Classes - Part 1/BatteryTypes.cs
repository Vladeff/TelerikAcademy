﻿namespace DefiningClassesPartI
{
    public enum BatteryTypes { LiIon, NiMH, NiCd }; //problem 3
}